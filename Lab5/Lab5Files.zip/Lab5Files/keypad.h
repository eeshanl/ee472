// Keypad header file containing prototypes of keypad functions

#ifndef KEYPAD_H
#define KEYPAD_H

void key_init();
int is_a_key();
int fresh_key();
int keymaster();
int getKey();

#endif
