// Few prototypes for the LED functions and other initializations

#ifndef MAIN_H
#define MAIN_H

void delay(unsigned long aValue);
void LED_init();
void LED_toggle();
void InitializeHardware();

#endif
